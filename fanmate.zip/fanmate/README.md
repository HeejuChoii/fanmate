# FanMate — Taste-Aware K-pop Fan Agent

FanMate is an AI fan-mate for K-pop fans. It remembers your bias, taste, budget and what you already own, and uses **Qloo's taste graph** to recommend brands, places and artists that truly fit you.

Built for the [Qloo Agentic Hackathon](https://qloo.devpost.com/).

## Why
Korean fans call copying what an idol wore or where they went *"Son Min-soo"*. In real fan chat rooms we analyzed (2,519 messages over 66 days), product-finding questions waited a median of 80 minutes for a first answer, and many were never answered. The originals are often too expensive or sold out. Generic LLMs guess; FanMate grounds every recommendation in Qloo.

## What it does
- **Taste-matched alternatives** — "My bias wore an Acne Studios scarf, my budget is $60" → resolves the brand in Qloo, then asks Qloo Insights for brands with similar taste.
- **Pilgrimage planning** — "I'm going to Seongsu next week" → Qloo place recommendations restricted to that area, seeded by the fan's taste.
- **Memory** — "I just bought a Carhartt beanie" → saved to the fan profile and used as a Qloo signal next time.
- **Transparent** — every answer shows the Qloo calls behind it ("How I found this").

## How it works
```
Fan message ──► Claude agent (tool use loop, app/api/chat)
                 ├─ qloo_search      → GET /search          (names → Qloo entity IDs)
                 ├─ qloo_find_tags   → GET /v2/tags         (vibes → tag IDs)
                 ├─ qloo_recommend   → GET /v2/insights     (brand / place / artist recs)
                 ├─ update_fan_profile (memory, stored in the browser)
                 └─ show_recommendations (cards in the UI)
```
- `lib/qloo.ts` — Qloo client (`X-Api-Key` header, hackathon base URL)
- `lib/agent.ts` — agent prompt, tools and loop
- `app/page.tsx` — chat UI with memory panel

## Run locally
```bash
npm install
cp .env.example .env.local   # add ANTHROPIC_API_KEY and QLOO_API_KEY
npm run dev
```
Set `QLOO_MOCK=1` to work on the UI with fake Qloo data (never used in the deployed demo).

## Deploy
Import the repo in Vercel and add `ANTHROPIC_API_KEY` and `QLOO_API_KEY` as environment variables.

## License
MIT
