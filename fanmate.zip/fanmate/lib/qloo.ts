// Thin server-side client for the Qloo hackathon API.
// Docs: https://docs.qloo.com/reference/qloo-llm-hackathon-developer-guide

const BASE_URL = process.env.QLOO_BASE_URL || "https://hackathon.api.qloo.com";

export const INSIGHT_TYPES = [
  "urn:entity:brand",
  "urn:entity:place",
  "urn:entity:artist",
  "urn:entity:destination",
  "urn:entity:movie",
  "urn:entity:tv_show",
  "urn:entity:book",
  "urn:entity:podcast",
  "urn:entity:person",
  "urn:entity:video_game",
] as const;

type Params = Record<string, string | number | string[] | undefined | null>;

function buildQuery(params: Params): string {
  const q = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v === undefined || v === null || v === "") continue;
    if (Array.isArray(v)) {
      if (v.length === 0) continue;
      q.set(k, v.join(","));
    } else {
      q.set(k, String(v));
    }
  }
  return q.toString();
}

export class QlooError extends Error {
  status?: number;
  constructor(message: string, status?: number) {
    super(message);
    this.status = status;
  }
}

async function qlooGet(path: string, params: Params): Promise<any> {
  if (process.env.QLOO_MOCK === "1") {
    const { mockQloo } = await import("./mock");
    return mockQloo(path, params);
  }
  const key = process.env.QLOO_API_KEY;
  if (!key) throw new QlooError("QLOO_API_KEY is not set on the server.");
  const url = `${BASE_URL}${path}?${buildQuery(params)}`;
  const res = await fetch(url, {
    headers: { "X-Api-Key": key, Accept: "application/json" },
    cache: "no-store",
  });
  if (!res.ok) {
    const body = await res.text().catch(() => "");
    throw new QlooError(`Qloo ${path} returned ${res.status}: ${body.slice(0, 300)}`, res.status);
  }
  return res.json();
}

// Keep only what the agent and the UI need, so prompts stay small.
export function slimEntity(e: any) {
  const p = e?.properties || {};
  const tags = Array.isArray(e?.tags)
    ? e.tags
        .map((t: any) => t?.name)
        .filter(Boolean)
        .slice(0, 6)
    : undefined;
  const image = p?.image?.url || (Array.isArray(p?.images) ? p.images[0]?.url : undefined);
  const out: Record<string, any> = {
    name: e?.name,
    entity_id: e?.entity_id,
    type: e?.subtype || e?.type || (Array.isArray(e?.types) ? e.types[0] : undefined),
    affinity: e?.query?.affinity,
    popularity: typeof e?.popularity === "number" ? Number(e.popularity.toFixed(3)) : undefined,
    address: p?.address,
    price_level: p?.price_level,
    rating: p?.business_rating,
    description: p?.short_description || p?.description,
    website: p?.website,
    image,
    tags,
  };
  if (typeof out.description === "string" && out.description.length > 220) {
    out.description = out.description.slice(0, 217) + "...";
  }
  for (const k of Object.keys(out)) if (out[k] === undefined || out[k] === null) delete out[k];
  return out;
}

function listFrom(payload: any, key: string): any[] {
  const r = payload?.results;
  if (Array.isArray(r)) return r;
  if (r && Array.isArray(r[key])) return r[key];
  if (Array.isArray(payload?.[key])) return payload[key];
  return [];
}

export async function searchEntities(input: { query: string; types?: string[]; take?: number }) {
  const data = await qlooGet("/search", {
    query: input.query,
    types: input.types,
    take: Math.min(input.take || 5, 10),
  });
  return listFrom(data, "entities").map(slimEntity);
}

export async function searchTags(input: { query: string; take?: number }) {
  const data = await qlooGet("/v2/tags", {
    "filter.query": input.query,
    take: Math.min(input.take || 6, 15),
  });
  return listFrom(data, "tags").map((t: any) => ({
    tag_id: t?.tag_id || t?.id,
    name: t?.name,
    type: t?.type || t?.subtype,
  }));
}

export async function getInsights(input: {
  filter_type: string;
  seed_entity_ids?: string[];
  seed_tag_ids?: string[];
  location?: string;
  price_level_max?: number;
  take?: number;
}) {
  if (!(INSIGHT_TYPES as readonly string[]).includes(input.filter_type)) {
    throw new QlooError(`Unsupported filter_type ${input.filter_type}`);
  }
  const params: Params = {
    "filter.type": input.filter_type,
    "signal.interests.entities": input.seed_entity_ids,
    "signal.interests.tags": input.seed_tag_ids,
    take: Math.min(input.take || 6, 12),
  };
  if (input.location) {
    if (input.filter_type === "urn:entity:place") params["filter.location.query"] = input.location;
    else params["signal.location.query"] = input.location;
  }
  if (input.price_level_max && input.filter_type === "urn:entity:place") {
    params["filter.price_level.max"] = input.price_level_max;
  }
  const data = await qlooGet("/v2/insights", params);
  return listFrom(data, "entities").map(slimEntity);
}
