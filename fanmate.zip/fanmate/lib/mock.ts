// Offline stand-in for the Qloo API, used only when QLOO_MOCK=1 (local development).
// The deployed demo always calls the real Qloo API.

const brands = [
  { name: "Sample Brand A", entity_id: "MOCK-BRAND-A", popularity: 0.81 },
  { name: "Sample Brand B", entity_id: "MOCK-BRAND-B", popularity: 0.64 },
  { name: "Sample Brand C", entity_id: "MOCK-BRAND-C", popularity: 0.52 },
];
const places = [
  { name: "Sample Cafe", entity_id: "MOCK-PLACE-1", address: "Hongdae, Seoul", price: 1 },
  { name: "Sample Vintage Shop", entity_id: "MOCK-PLACE-2", address: "Mapo-gu, Seoul", price: 2 },
];

export function mockQloo(path: string, params: Record<string, any>) {
  if (path === "/search") {
    return {
      results: [
        {
          name: String(params.query),
          entity_id: "MOCK-SEED-1",
          types: [String(params.types || "urn:entity:brand").split(",")[0]],
          popularity: 0.9,
        },
      ],
    };
  }
  if (path === "/v2/tags") {
    return { results: { tags: [{ tag_id: "urn:tag:style:mock", name: `${params["filter.query"]} (mock tag)` }] } };
  }
  if (path === "/v2/insights") {
    const isPlace = params["filter.type"] === "urn:entity:place";
    const rows = isPlace
      ? places.map((p, i) => ({
          name: p.name,
          entity_id: p.entity_id,
          subtype: "urn:entity:place",
          query: { affinity: 0.9 - i * 0.1 },
          properties: { address: p.address, price_level: p.price },
        }))
      : brands.map((b, i) => ({ ...b, subtype: params["filter.type"], query: { affinity: 0.92 - i * 0.07 } }));
    return { results: { entities: rows } };
  }
  return { results: [] };
}
