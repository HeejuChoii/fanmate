import Anthropic from "@anthropic-ai/sdk";
import { getInsights, INSIGHT_TYPES, searchEntities, searchTags } from "./qloo";

export type FanProfile = {
  bias?: string;
  group?: string;
  budget_usd?: number;
  style?: string;
  home_city?: string;
  owned: string[];
  visited: string[];
  loved: { name: string; entity_id?: string; type?: string }[];
};

export const emptyProfile = (): FanProfile => ({ owned: [], visited: [], loved: [] });

export type Card = {
  name: string;
  kind: string;
  why: string;
  entity_id?: string;
  address?: string;
  image?: string;
  affinity?: number;
};

export type CardGroup = { title: string; items: Card[] };
export type TraceStep = { tool: string; summary: string; ok: boolean };
export type ChatMessage = { role: "user" | "assistant"; content: string };

const MODEL = process.env.CLAUDE_MODEL || "claude-sonnet-5-5";
const MAX_STEPS = 8;

const SYSTEM = `You are FanMate, a warm, sharp companion for K-pop fans ("a fan-mate", what Korean fans call a "dukme").
Fans love "Son Min-soo" culture: copying what their idol (their "bias") wore, used, ate, or where they went.

Your superpower is Qloo's taste graph. Use it; never rely on your own guesses for recommendations.

How to work:
1. Resolve: turn brands, places, artists or shows the fan mentions into Qloo entities with qloo_search. Turn vibes or styles ("y2k", "minimal", "streetwear", "cozy cafe") into tag IDs with qloo_find_tags when useful.
2. Recommend: call qloo_recommend with those IDs as seeds. Typical moves:
   - Idol wore an expensive brand -> recommend urn:entity:brand seeded by that brand (and the fan's loved brands) to find brands with similar taste the fan may afford.
   - Idol visited a place / fan is going to a neighborhood -> recommend urn:entity:place with location set to that area (e.g. "Hongdae, Seoul"), seeded by the idol's place and the fan's taste.
   - Fan wants music or shows -> urn:entity:artist / urn:entity:tv_show seeded by their bias's group and loved entities.
   Always add the fan's remembered loved entities as extra seeds so results are personal.
3. Show: call show_recommendations once per answer with your 3-6 best picks from Qloo results, each with a one-line reason tied to the fan's taste. Only include items that came back from Qloo.
4. Remember: whenever the fan tells you their bias, group, budget, style, home city, something they bought, a place they visited, or something they love, call update_fan_profile. When they bought something, future picks should avoid repeating it and build on it.

Rules:
- Facts about what an idol wore or visited come from the fan. Do not invent idol facts. If unsure, ask.
- Qloo does not return individual products or prices for brands. Say "brands with a similar vibe", and for budget, prefer brands with lower popularity/price signals and tell the fan honestly.
- If Qloo returns nothing (some regions have sparse data), say so, broaden (e.g. "Seoul" instead of a street), and try once more.
- Reply in the fan's language. Keep the chat reply short (2-5 sentences); the cards carry the detail. Be playful, use fan words naturally (bias, comeback, pilgrimage), no emoji spam.`;

const tools: Anthropic.Tool[] = [
  {
    name: "qloo_search",
    description:
      "Look up Qloo entities by name (brands, places, artists, shows, etc.) to get their entity_id. Use before qloo_recommend.",
    input_schema: {
      type: "object",
      properties: {
        query: { type: "string", description: "Name to look up, e.g. 'Ader Error' or 'Seongsu cafe Onion'" },
        types: {
          type: "array",
          items: { type: "string", enum: [...INSIGHT_TYPES] },
          description: "Optional entity types to restrict the search.",
        },
        take: { type: "integer", minimum: 1, maximum: 10 },
      },
      required: ["query"],
    },
  },
  {
    name: "qloo_find_tags",
    description: "Find Qloo tag IDs for a style, vibe, genre or cuisine keyword, e.g. 'streetwear', 'minimalist', 'dessert cafe'.",
    input_schema: {
      type: "object",
      properties: { query: { type: "string" }, take: { type: "integer", minimum: 1, maximum: 15 } },
      required: ["query"],
    },
  },
  {
    name: "qloo_recommend",
    description:
      "Qloo Insights: taste-based recommendations of one entity type, seeded by entity IDs and/or tag IDs. For places, set location to restrict results to an area.",
    input_schema: {
      type: "object",
      properties: {
        filter_type: { type: "string", enum: [...INSIGHT_TYPES] },
        seed_entity_ids: { type: "array", items: { type: "string" } },
        seed_tag_ids: { type: "array", items: { type: "string" } },
        location: { type: "string", description: "e.g. 'Hongdae, Seoul' or 'Seoul'" },
        price_level_max: { type: "integer", minimum: 1, maximum: 4, description: "Places only. 1 = cheapest." },
        take: { type: "integer", minimum: 1, maximum: 12 },
      },
      required: ["filter_type"],
    },
  },
  {
    name: "update_fan_profile",
    description: "Save what you learned about the fan so future recommendations are personal.",
    input_schema: {
      type: "object",
      properties: {
        bias: { type: "string" },
        group: { type: "string" },
        budget_usd: { type: "number" },
        style: { type: "string" },
        home_city: { type: "string" },
        owned_add: { type: "array", items: { type: "string" } },
        visited_add: { type: "array", items: { type: "string" } },
        loved_add: {
          type: "array",
          items: {
            type: "object",
            properties: { name: { type: "string" }, entity_id: { type: "string" }, type: { type: "string" } },
            required: ["name"],
          },
        },
      },
    },
  },
  {
    name: "show_recommendations",
    description: "Display recommendation cards to the fan. Call once per answer with picks taken from Qloo results.",
    input_schema: {
      type: "object",
      properties: {
        title: { type: "string" },
        items: {
          type: "array",
          items: {
            type: "object",
            properties: {
              name: { type: "string" },
              kind: { type: "string", description: "brand, place, artist, show..." },
              why: { type: "string", description: "One line, tied to the fan's taste." },
              entity_id: { type: "string" },
              address: { type: "string" },
              image: { type: "string" },
              affinity: { type: "number" },
            },
            required: ["name", "kind", "why"],
          },
        },
      },
      required: ["title", "items"],
    },
  },
];

function applyProfile(p: FanProfile, u: any): FanProfile {
  const next: FanProfile = { ...p, owned: [...p.owned], visited: [...p.visited], loved: [...p.loved] };
  for (const k of ["bias", "group", "style", "home_city"] as const) if (u?.[k]) next[k] = String(u[k]);
  if (typeof u?.budget_usd === "number") next.budget_usd = u.budget_usd;
  const addUnique = (arr: string[], items: any) => {
    for (const it of Array.isArray(items) ? items : []) if (it && !arr.includes(it)) arr.push(String(it));
  };
  addUnique(next.owned, u?.owned_add);
  addUnique(next.visited, u?.visited_add);
  for (const l of Array.isArray(u?.loved_add) ? u.loved_add : []) {
    if (l?.name && !next.loved.some((x) => x.name.toLowerCase() === String(l.name).toLowerCase())) next.loved.push(l);
  }
  next.loved = next.loved.slice(-15);
  return next;
}

export async function runAgent(history: ChatMessage[], profileIn: FanProfile) {
  const client = new Anthropic(); // reads ANTHROPIC_API_KEY
  let profile = { ...emptyProfile(), ...profileIn };
  const cards: CardGroup[] = [];
  const trace: TraceStep[] = [];

  const messages: Anthropic.MessageParam[] = history.slice(-12).map((m) => ({ role: m.role, content: m.content }));
  const profileNote = `Current remembered fan profile (JSON): ${JSON.stringify(profile)}`;

  for (let step = 0; step < MAX_STEPS; step++) {
    const res = await client.messages.create({
      model: MODEL,
      max_tokens: 1500,
      system: `${SYSTEM}\n\n${profileNote}`,
      tools,
      messages,
    });

    messages.push({ role: "assistant", content: res.content });
    const toolUses = res.content.filter((b): b is Anthropic.ToolUseBlock => b.type === "tool_use");

    if (res.stop_reason !== "tool_use" || toolUses.length === 0) {
      const reply = res.content
        .filter((b): b is Anthropic.TextBlock => b.type === "text")
        .map((b) => b.text)
        .join("\n")
        .trim();
      return { reply, cards, profile, trace };
    }

    const results: Anthropic.ToolResultBlockParam[] = await Promise.all(
      toolUses.map(async (tu) => {
        const input = tu.input as any;
        try {
          let out: any;
          switch (tu.name) {
            case "qloo_search":
              out = await searchEntities(input);
              trace.push({ tool: "Qloo /search", summary: `"${input.query}" → ${out.length} match(es)`, ok: true });
              break;
            case "qloo_find_tags":
              out = await searchTags(input);
              trace.push({ tool: "Qloo /v2/tags", summary: `"${input.query}" → ${out.length} tag(s)`, ok: true });
              break;
            case "qloo_recommend": {
              out = await getInsights(input);
              const t = String(input.filter_type).replace("urn:entity:", "");
              const seeds = (input.seed_entity_ids?.length || 0) + (input.seed_tag_ids?.length || 0);
              trace.push({
                tool: "Qloo /v2/insights",
                summary: `${t}${input.location ? ` in ${input.location}` : ""}, ${seeds} seed(s) → ${out.length} result(s)`,
                ok: true,
              });
              break;
            }
            case "update_fan_profile":
              profile = applyProfile(profile, input);
              out = { saved: true, profile };
              trace.push({ tool: "Memory", summary: "fan profile updated", ok: true });
              break;
            case "show_recommendations":
              cards.push({ title: String(input.title || "Picks"), items: Array.isArray(input.items) ? input.items : [] });
              out = { shown: true };
              break;
            default:
              out = { error: "unknown tool" };
          }
          return { type: "tool_result", tool_use_id: tu.id, content: JSON.stringify(out) } as Anthropic.ToolResultBlockParam;
        } catch (err: any) {
          trace.push({ tool: tu.name, summary: String(err?.message || err).slice(0, 120), ok: false });
          return {
            type: "tool_result",
            tool_use_id: tu.id,
            is_error: true,
            content: `Error: ${String(err?.message || err).slice(0, 400)}`,
          } as Anthropic.ToolResultBlockParam;
        }
      })
    );
    messages.push({ role: "user", content: results });
  }

  return {
    reply: "I dug through a lot of taste data there. Here's what I found so far. Want me to narrow it down?",
    cards,
    profile,
    trace,
  };
}
