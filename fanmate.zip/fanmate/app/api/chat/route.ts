import { NextResponse } from "next/server";
import { emptyProfile, runAgent, type ChatMessage, type FanProfile } from "@/lib/agent";

export const runtime = "nodejs";
export const maxDuration = 60;

export async function POST(req: Request) {
  let body: { messages?: ChatMessage[]; profile?: FanProfile };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }

  const messages = (body.messages || [])
    .filter((m) => (m.role === "user" || m.role === "assistant") && typeof m.content === "string" && m.content.trim())
    .map((m) => ({ role: m.role, content: m.content.slice(0, 2000) }));

  if (messages.length === 0 || messages[messages.length - 1].role !== "user") {
    return NextResponse.json({ error: "Last message must be from the user" }, { status: 400 });
  }
  if (!process.env.ANTHROPIC_API_KEY) {
    return NextResponse.json({ error: "ANTHROPIC_API_KEY is not set on the server." }, { status: 500 });
  }

  // The conversation must start with a user turn.
  while (messages.length && messages[0].role !== "user") messages.shift();

  try {
    const result = await runAgent(messages, { ...emptyProfile(), ...(body.profile || {}) });
    return NextResponse.json(result);
  } catch (err: any) {
    console.error(err);
    return NextResponse.json({ error: String(err?.message || err).slice(0, 300) }, { status: 500 });
  }
}
