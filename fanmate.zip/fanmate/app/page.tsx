"use client";

import { useEffect, useRef, useState } from "react";
import type { CardGroup, ChatMessage, FanProfile, TraceStep } from "@/lib/agent";

type Turn = ChatMessage & { cards?: CardGroup[]; trace?: TraceStep[]; error?: boolean };

const STORAGE_KEY = "fanmate.v1";
const blankProfile = (): FanProfile => ({ owned: [], visited: [], loved: [] });

const EXAMPLES = [
  "My bias wore an Acne Studios scarf in a fan photo. Find brands with that vibe I can actually afford — my budget is $60.",
  "I'm going to Seongsu, Seoul next week for a pilgrimage. Find cafés and spots there that match my taste.",
  "I just bought a Carhartt beanie! Remember it and suggest what to pair it with.",
  "I love NewJeans and Red Velvet. Which artists should I check out next?",
];

function load(): { turns: Turn[]; profile: FanProfile } {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return { turns: parsed.turns || [], profile: { ...blankProfile(), ...(parsed.profile || {}) } };
    }
  } catch {}
  return { turns: [], profile: blankProfile() };
}

function save(turns: Turn[], profile: FanProfile) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ turns: turns.slice(-30), profile }));
  } catch {}
}

export default function Home() {
  const [turns, setTurns] = useState<Turn[]>([]);
  const [profile, setProfile] = useState<FanProfile>(blankProfile());
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [ready, setReady] = useState(false);
  const [showProfile, setShowProfile] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const s = load();
    setTurns(s.turns);
    setProfile(s.profile);
    setReady(true);
  }, []);

  useEffect(() => {
    if (ready) save(turns, profile);
  }, [turns, profile, ready]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [turns, busy]);

  async function send(text: string) {
    const content = text.trim();
    if (!content || busy) return;
    const next: Turn[] = [...turns, { role: "user", content }];
    setTurns(next);
    setInput("");
    setBusy(true);
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: next.filter((t) => !t.error).map(({ role, content }) => ({ role, content })),
          profile,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || `Request failed (${res.status})`);
      setProfile(data.profile || profile);
      setTurns([
        ...next,
        { role: "assistant", content: data.reply || "Here's what I found.", cards: data.cards, trace: data.trace },
      ]);
    } catch (e: any) {
      setTurns([...next, { role: "assistant", content: `Something went wrong: ${e.message}`, error: true }]);
    } finally {
      setBusy(false);
    }
  }

  function reset() {
    if (!confirm("Forget this chat and your fan profile?")) return;
    setTurns([]);
    setProfile(blankProfile());
  }

  const memoryCount =
    (profile.bias ? 1 : 0) +
    (profile.group ? 1 : 0) +
    (profile.budget_usd ? 1 : 0) +
    (profile.style ? 1 : 0) +
    profile.owned.length +
    profile.visited.length +
    profile.loved.length;

  return (
    <div className="shell">
      <header className="top">
        <div className="brand">
          <span className="logo" aria-hidden>
            ✦
          </span>
          <div>
            <h1>FanMate</h1>
            <p>Your K-pop fan-mate with real taste · powered by Qloo</p>
          </div>
        </div>
        <button className="ghost profile-toggle" onClick={() => setShowProfile((v) => !v)}>
          Memory <span className="pill">{memoryCount}</span>
        </button>
      </header>

      <div className="layout">
        <main className="chat">
          {turns.length === 0 && (
            <section className="hello">
              <h2>
                Find what your bias wore, <em>in your budget.</em>
              </h2>
              <p>
                Tell me who your bias is, what they wore or where they went, and what you can spend. I&apos;ll use
                Qloo&apos;s taste graph to find brands, places and artists that match <b>your</b> taste — and I&apos;ll
                remember it for next time.
              </p>
              <div className="examples">
                {EXAMPLES.map((ex) => (
                  <button key={ex} onClick={() => send(ex)} disabled={busy}>
                    {ex}
                  </button>
                ))}
              </div>
            </section>
          )}

          {turns.map((t, i) => (
            <div key={i} className={`turn ${t.role}${t.error ? " error" : ""}`}>
              <div className="bubble">{t.content}</div>
              {t.cards?.map((g, gi) => (
                <div key={gi} className="cardgroup">
                  <h3>{g.title}</h3>
                  <div className="cards">
                    {g.items.map((c, ci) => (
                      <article key={ci} className="card">
                        {c.image ? (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img src={c.image} alt="" loading="lazy" />
                        ) : (
                          <div className="ph" aria-hidden>
                            {c.name.slice(0, 1)}
                          </div>
                        )}
                        <div className="body">
                          <span className="kind">{c.kind}</span>
                          <h4>{c.name}</h4>
                          {c.address && <p className="addr">{c.address}</p>}
                          <p className="why">{c.why}</p>
                          {typeof c.affinity === "number" && (
                            <div className="meter" title="Qloo taste affinity">
                              <span style={{ width: `${Math.round(Math.min(1, Math.max(0, c.affinity)) * 100)}%` }} />
                            </div>
                          )}
                        </div>
                      </article>
                    ))}
                  </div>
                </div>
              ))}
              {t.trace && t.trace.length > 0 && (
                <details className="trace">
                  <summary>How I found this · {t.trace.length} step(s)</summary>
                  <ul>
                    {t.trace.map((s, si) => (
                      <li key={si} className={s.ok ? "" : "bad"}>
                        <b>{s.tool}</b> {s.summary}
                      </li>
                    ))}
                  </ul>
                </details>
              )}
            </div>
          ))}

          {busy && (
            <div className="turn assistant">
              <div className="bubble typing">
                Checking Qloo&apos;s taste graph<span>.</span>
                <span>.</span>
                <span>.</span>
              </div>
            </div>
          )}
          <div ref={endRef} />

          <form
            className="composer"
            onSubmit={(e) => {
              e.preventDefault();
              send(input);
            }}
          >
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) {
                  e.preventDefault();
                  send(input);
                }
              }}
              placeholder="e.g. My bias is from RIIZE and I love minimal streetwear…"
              rows={2}
            />
            <button type="submit" disabled={busy || !input.trim()}>
              Send
            </button>
          </form>
        </main>

        <aside className={`memory ${showProfile ? "open" : ""}`}>
          <div className="memhead">
            <h2>What I remember</h2>
            <button className="ghost small" onClick={reset}>
              Reset
            </button>
          </div>
          <dl>
            <dt>Bias</dt>
            <dd>{[profile.bias, profile.group].filter(Boolean).join(" · ") || "—"}</dd>
            <dt>Budget</dt>
            <dd>{profile.budget_usd ? `$${profile.budget_usd}` : "—"}</dd>
            <dt>Style</dt>
            <dd>{profile.style || "—"}</dd>
            <dt>Loves</dt>
            <dd>
              {profile.loved.length ? (
                <div className="chips">
                  {profile.loved.map((l) => (
                    <span key={l.name}>{l.name}</span>
                  ))}
                </div>
              ) : (
                "—"
              )}
            </dd>
            <dt>Already owns</dt>
            <dd>
              {profile.owned.length ? (
                <div className="chips">
                  {profile.owned.map((o) => (
                    <span key={o}>{o}</span>
                  ))}
                </div>
              ) : (
                "—"
              )}
            </dd>
            <dt>Pilgrimages</dt>
            <dd>
              {profile.visited.length ? (
                <div className="chips">
                  {profile.visited.map((o) => (
                    <span key={o}>{o}</span>
                  ))}
                </div>
              ) : (
                "—"
              )}
            </dd>
          </dl>
          <p className="fine">Saved only in this browser. Recommendations come from Qloo&apos;s taste graph.</p>
        </aside>
      </div>
    </div>
  );
}
